package com.example.assignment3;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
