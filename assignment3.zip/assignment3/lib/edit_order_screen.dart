import 'package:flutter/material.dart';
import 'db_helper.dart';

class EditOrderScreen extends StatefulWidget {
  final Map<String, dynamic> order;

  const EditOrderScreen({super.key, required this.order});

  @override
  State<EditOrderScreen> createState() => EditOrderScreenState();
}

class EditOrderScreenState extends State<EditOrderScreen> {
  final DatabaseHelper dbHelper = DatabaseHelper();
  late TextEditingController dateController;
  late TextEditingController targetCostController;
  late List<Map<String, dynamic>> foodItems;
  late Map<int, bool> selectedItems;
  double totalCost = 0;
  late String selectedFoodItems;

  @override
  void initState() {
    super.initState();

    dateController = TextEditingController(text: widget.order['date']);
    targetCostController = TextEditingController(text: widget.order['total_cost'].toString());

    loadFoodItems();
  }

  Future<void> loadFoodItems() async {
    final items = await dbHelper.getAllFoodItems();
    setState(() {
      foodItems = items;
      selectedItems = {
        for (var item in items) item['id']: widget.order['food_items'].contains(item['name']),
      };
      selectedFoodItems = widget.order['food_items'];
      totalCost = widget.order['total_cost'];
    });
  }

  void onFoodItemToggle(int id, double cost, bool? selected) {
    setState(() {
      selectedItems[id] = selected ?? false;
      totalCost += selected! ? cost : -cost;
    });
  }

  void updateOrder() async {

    double? targetCost = double.tryParse(targetCostController.text);

    if (dateController.text.isEmpty || selectedFoodItems.isEmpty || targetCostController.text.isEmpty || targetCost! < totalCost) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid inputs')),
      );
      return;
    }

    final updatedFoodItems = foodItems
        .where((item) => selectedItems[item['id']]!)
        .map((item) => item['name'])
        .join(', ');

    await dbHelper.updateOrderPlan(
      widget.order['id'],
      dateController.text,
      updatedFoodItems,
      totalCost,
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Edit Order')),
      body: foodItems.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: dateController,
              decoration: const InputDecoration(labelText: 'Enter Date (YYYY-MM-DD)'),
            ),
            TextField(
              controller: targetCostController,
              decoration: const InputDecoration(labelText: 'Enter Target Cost (Maximum Cost)'),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: foodItems.map((item) {
                  return CheckboxListTile(
                    title: Text('${item['name']} - \$${item['cost']}'),
                    value: selectedItems[item['id']],
                    onChanged: (value) => onFoodItemToggle(item['id'], item['cost'], value),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 20),
            Text('Total Cost: \$${totalCost.toStringAsFixed(2)}'),
            ElevatedButton(
              onPressed: updateOrder,
              child: const Text('Update Order'),
            ),
          ],
        ),
      ),
    );
  }
}
