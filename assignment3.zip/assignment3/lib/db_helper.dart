import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper.internal();
  static Database? _database;

  factory DatabaseHelper() => instance;

  DatabaseHelper.internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await initDatabase();
    return _database!;
  }

  Future<Database> initDatabase() async {
    String path = join(await getDatabasesPath(), 'food_ordering.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE food_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            cost REAL NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE order_plans(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            food_items TEXT NOT NULL,
            total_cost REAL NOT NULL
          )
        ''');
        await db.execute(
            '''INSERT INTO food_items (name, cost) VALUES
            ('Chicken Burger', 5.99),
            ('Margherita Pizza', 8.49),
            ('Caesar Salad', 4.99),
            ('Spaghetti Bolognese', 7.99),
            ('Grilled Chicken', 9.99),
            ('Veggie Sandwich', 4.49),
            ('Cheese Nachos', 6.49),
            ('Beef Tacos', 7.29),
            ('Mushroom Soup', 3.99),
            ('Chicken Wings', 6.99),
            ('Fish and Chips', 9.49),
            ('Egg Fried Rice', 5.29),
            ('Paneer Tikka', 7.49),
            ('BBQ Ribs', 12.99),
            ('Veggie Wrap', 4.79),
            ('Pancakes', 3.49),
            ('Chocolate Brownie', 2.99),
            ('Grilled Salmon', 14.99),
            ('Fruit Smoothie', 3.99),
            ('Garlic Bread', 2.49)'''
        );
      },
    );
  }

  Future<int> addFoodItem(String name, double cost) async {
    final db = await database;
    return await db.insert('food_items', {'name': name, 'cost': cost});
  }

  Future<List<Map<String, dynamic>>> getAllFoodItems() async {
    final db = await database;
    return await db.query('food_items');
  }

  Future<int> deleteFoodItem(int id) async {
    final db = await database;
    return await db.delete('food_items', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> updateFoodItem(int id, String name, double cost) async {
    final db = await database;
    return await db.update(
      'food_items',
      {'name': name, 'cost': cost},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> saveOrderPlan(String date, String foodItems, double totalCost) async {
    final db = await database;
    return await db.insert('order_plans', {'date': date, 'food_items': foodItems, 'total_cost': totalCost});
  }

  Future<Map<String, dynamic>?> getOrderPlan(String date) async {
    final db = await database;
    final result = await db.query('order_plans', where: 'date = ?', whereArgs: [date]);
    if (result.isNotEmpty) {
      return result.first;
    }
    return null;
  }

  Future<List<Map<String, dynamic>>> getAllOrders() async {
    final db = await database;
    return await db.query('order_plans');
  }

  Future<int> updateOrderPlan(int id, String date, String foodItems, double totalCost) async {
    final db = await database;
    return await db.update(
      'order_plans',
      {'date': date, 'food_items': foodItems, 'total_cost': totalCost},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteOrderPlan(int id) async {
    final db = await database;
    return await db.delete(
      'order_plans',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
