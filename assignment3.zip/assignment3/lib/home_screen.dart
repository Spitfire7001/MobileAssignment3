import 'package:flutter/material.dart';
import 'db_helper.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  final DatabaseHelper dbHelper = DatabaseHelper();
  List<Map<String, dynamic>> foodItems = [];
  Map<int, bool> selectedItems = {};
  double totalCost = 0;

  final TextEditingController dateController = TextEditingController();
  final TextEditingController targetCostController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadFoodItems();
  }

  Future<void> loadFoodItems() async {
    final items = await dbHelper.getAllFoodItems();
    setState(() {
      foodItems = items;
      selectedItems = {for (var item in items) item['id']: false};
    });
  }

  void onFoodItemToggle(int id, double cost, bool? selected) {
    setState(() {
      selectedItems[id] = selected ?? false;
      totalCost += selected! ? cost : -cost;
    });
  }

  void saveOrderPlan() async {
    final selectedFoodItems = foodItems.where((item) => selectedItems[item['id']]!).toList();

    double? targetCost = double.tryParse(targetCostController.text);
    if (dateController.text.isEmpty || selectedFoodItems.isEmpty
        || targetCostController.text.isEmpty || targetCost! < totalCost) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid inputs')),
      );
      return;
    }

    final selectedFood = foodItems
        .where((item) => selectedItems[item['id']]!)
        .map((item) => item['name'])
        .join(', ');

    await dbHelper.saveOrderPlan(dateController.text, selectedFood, totalCost);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Order plan saved successfully')),
    );
    resetForm();
  }

  void resetForm() {
    setState(() {
      dateController.clear();
      targetCostController.clear();
      selectedItems = {for (var item in foodItems) item['id']: false};
      totalCost = 0;
    });
  }

  void showAddFoodDialog() {
    final foodNameController = TextEditingController();
    final costController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add New Food Item'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: foodNameController,
                decoration: const InputDecoration(labelText: 'Food Name'),
              ),
              TextField(
                controller: costController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Cost'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                final foodName = foodNameController.text;
                final cost = double.tryParse(costController.text) ?? 0.0;
                if (foodName.isNotEmpty && cost > 0) {
                  dbHelper.addFoodItem(foodName, cost);
                  loadFoodItems();
                  Navigator.pop(context);
                }
              },
              child: const Text('Add'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  void showEditFoodDialog(Map<String, dynamic> foodItem) {
    final foodNameController = TextEditingController(text: foodItem['name']);
    final costController = TextEditingController(text: foodItem['cost'].toString());

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit Food Item'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: foodNameController,
                decoration: const InputDecoration(labelText: 'Food Name'),
              ),
              TextField(
                controller: costController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Cost'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                final foodName = foodNameController.text;
                final cost = double.tryParse(costController.text) ?? 0.0;
                if (foodName.isNotEmpty && cost > 0) {
                  dbHelper.updateFoodItem(foodItem['id'], foodName, cost);
                  loadFoodItems();
                  Navigator.pop(context);
                }
              },
              child: const Text('Save'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }
  
  void deleteFoodItem(int id) async {
    await dbHelper.deleteFoodItem(id);
    loadFoodItems();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Food Ordering App'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: showAddFoodDialog,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: dateController,
              decoration: const InputDecoration(labelText: 'Enter Date (YYYY-MM-DD)'),
            ),
            TextField(
              controller: targetCostController,
              decoration: const InputDecoration(labelText: 'Enter Target Cost (Maximum Cost)'),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: foodItems.map((item) {
                  return CheckboxListTile(
                    title: Text('${item['name']} - \$${item['cost']}'),
                    value: selectedItems[item['id']],
                    onChanged: (value) => onFoodItemToggle(item['id'], item['cost'], value),
                    secondary: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () => showEditFoodDialog(item),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () => deleteFoodItem(item['id']),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 20),
            Text('Total Cost: \$${totalCost.toStringAsFixed(2)}'),
            ElevatedButton(
              onPressed: saveOrderPlan,
              child: const Text('Save Order Plan'),
            ),
          ],
        ),
      ),
    );
  }
}
