import 'package:flutter/material.dart';
import 'db_helper.dart';
import 'edit_order_screen.dart';

class OrderScreen extends StatefulWidget {
  const OrderScreen({super.key});

  @override
  State<OrderScreen> createState() => _OrderScreenState();
}

class _OrderScreenState extends State<OrderScreen> {
  final DatabaseHelper dbHelper = DatabaseHelper();
  List<Map<String, dynamic>> allOrders = [];
  List<Map<String, dynamic>> filteredOrders = [];
  TextEditingController dateSearchController = TextEditingController();
  TextEditingController priceSearchController = TextEditingController();
  String dateQuery = '';
  String priceQuery = '';

  @override
  void initState() {
    super.initState();
    loadOrders();
    dateSearchController.addListener(filterOrders);
    priceSearchController.addListener(filterOrders);
  }

  Future<void> loadOrders() async {
    final orders = await dbHelper.getAllOrders();
    setState(() {
      allOrders = orders;
      filteredOrders = orders;
    });
  }

  void filterOrders() {
    setState(() {
      dateQuery = dateSearchController.text;
      priceQuery = priceSearchController.text;

      filteredOrders = allOrders.where((order) {
        final dateMatch = order['date'].toString().contains(dateQuery);
        final costMatch = order['total_cost']
            .toString()
            .contains(priceQuery);
        return dateMatch && costMatch;
      }).toList();
    });
  }

  Future<void> deleteOrder(int orderId) async {
    await dbHelper.deleteOrderPlan(orderId);
    loadOrders();
  }

  @override
  void dispose() {
    dateSearchController.dispose();
    priceSearchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Order History')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                TextField(
                  controller: dateSearchController,
                  decoration: const InputDecoration(
                    labelText: 'Search by Date (YYYY-MM-DD)',
                    prefixIcon: Icon(Icons.calendar_today),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: priceSearchController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Search by Total Price',
                    prefixIcon: Icon(Icons.attach_money),
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          filteredOrders.isEmpty
              ? const Center(child: Text('No orders found'))
              : Expanded(
            child: ListView.builder(
              itemCount: filteredOrders.length,
              itemBuilder: (context, index) {
                final order = filteredOrders[index];
                return ListTile(
                  title: Text('Date: ${order['date']}'),
                  subtitle: Text('Items: ${order['food_items']}'),
                  trailing: Text('Total: \$${order['total_cost']}'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EditOrderScreen(order: order),
                      ),
                    ).then((_) {
                      loadOrders();
                    });
                  },
                  leading: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () async {
                      final shouldDelete = await showDialog<bool>(
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            title: const Text('Delete Order'),
                            content: const Text('Are you sure you want to delete this order?'),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context, false),
                                child: const Text('Cancel'),
                              ),
                              TextButton(
                                onPressed: () => Navigator.pop(context, true),
                                child: const Text('Delete'),
                              ),
                            ],
                          );
                        },
                      );
                      if (shouldDelete == true) {
                        await deleteOrder(order['id']);
                      }
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
